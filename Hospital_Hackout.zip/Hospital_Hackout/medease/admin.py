from django.contrib import admin

# Register your models here.
from .models import patient,doctor,chemist
from .models import prescription,patient_med_detail


class showPatient(admin.ModelAdmin):
    list_display=('username','first_name','last_name','phone','email','password')
admin.site.register(patient,showPatient)


class showDoctor(admin.ModelAdmin):
    list_display=('username','first_name','last_name','speciality','phone','email','password')
admin.site.register(doctor,showDoctor)


class showChemist(admin.ModelAdmin):
    list_display=('username','first_name','last_name','phone','email','password')
admin.site.register(chemist,showChemist)


class showPrescription(admin.ModelAdmin):
    list_display=('p_id','d_id','medicines')
admin.site.register(prescription,showPrescription)


class showPatient_med_detail(admin.ModelAdmin):
    list_display = ('p_id','d_id','symptoms','illness')
admin.site.register(patient_med_detail,showPatient_med_detail)