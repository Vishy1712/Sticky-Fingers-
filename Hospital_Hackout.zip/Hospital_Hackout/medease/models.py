from django.db import models

# Create your models here.
class patient(models.Model):
    username = models.CharField(max_length=15)
    first_name = models.CharField(max_length=15)
    last_name = models.CharField(max_length=15)
    phone = models.IntegerField()
    email = models.CharField(max_length=15)
    password = models.CharField(max_length=8)

    def __str__(self):
        return self.username


class doctor(models.Model):
    username = models.CharField(max_length=15)
    first_name=models.CharField(max_length=15)
    last_name=models.CharField(max_length=15)
    speciality=models.CharField(max_length=15)
    phone = models.IntegerField()
    email = models.CharField(max_length=15)
    password = models.CharField(max_length=8)


    def __str__(self):
        return self.username

class chemist(models.Model):
    username = models.CharField(max_length=15)
    first_name = models.CharField(max_length=15)
    last_name = models.CharField(max_length=15)
    phone = models.IntegerField()
    email = models.CharField(max_length=15)
    password = models.CharField(max_length=8)

    def __str__(self):
        return self.username

class prescription(models.Model):
    p_id = models.ForeignKey(patient, on_delete=models.CASCADE)
    d_id = models.ForeignKey(doctor, on_delete=models.CASCADE)
    medicines = models.CharField(max_length=50)

class patient_med_detail(models.Model):
    p_id = models.ForeignKey(patient, on_delete=models.CASCADE)
    d_id = models.ForeignKey(doctor, on_delete=models.CASCADE)
    symptoms = models.CharField(max_length=50)
    illness = models.CharField(max_length=50)


